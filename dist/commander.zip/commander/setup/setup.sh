sudo mkdir /etc/commander
sudo cp *.py /etc/commander/
sudo cp launcher.sh /etc/commander/launcher.sh
sudo cp commander.conf /etc/init
chmod 775 commander.conf
sudo initctl reload-configuration
sudo initctl start commander