import os, shutil, urllib2, getpass
import crypt, compressor, explit, wipe

def cd(path):
    return os.chdir(path)

def rm(path):
    if os.path.isfile(path):
        return os.remove(path)
    else:
        return shutil.rmtree(path)

def wp(path):
    if os.path.isfile(path):
        return wipe.recursiveWipe(path)
    else:
        return wipe.wipeDirectory(path)

def md(path):
    os.makedirs(path)

def download(url, target):
    open(target, 'wb').write(urllib2.urlopen(url).read())
    return "OK"

def encrypt(filename, key):
    if os.path.isfile(filename):
        IV = crypt.encrypt(filename, key)
        wipe.recursiveWipe(filename)
        return IV
    elif os.path.exists(filename):
        compressor.zipDirectory(filename)
        IV = crypt.encrypt(filename + '.zip', key)
        wipe.wipeDirectory(filename)
        wipe.recursiveWipe(filename + '.zip')
        return IV

def decrypt(inputfile, key, IV):
    filename = crypt.decrypt(inputfile, key, IV)
    if filename.endswith(".zip"):
        compressor.unzipDirectory(filename)
        wipe.recursiveWipe(filename)
        wipe.recursiveWipe(inputfile)

def other(cmd):
    output = os.popen(cmd).read()
    return output

def execute(command):
    if command.startswith("cd "):
        cd(command[3:])
    elif command.startswith("rm "):
        rm(command[3:])
    elif command.startswith("wipe "):
        wp(command[5:])
    elif command.startswith("md "):
        md(command[3:])
    elif command.startswith("download "):
        url = command.find(' ') + 1
        path = command.rfind(' ')
        return download(command[url:path], command[path:])
    elif command.startswith("encrypt "):
        filename = command.find(' ') + 1
        key = filename + command[filename:].find(' ')
        IV = encrypt(command[filename:key], command[key:])
        open(raw_input("save the keyfile as: "), 'wb').write(IV)
        return 'encrypted'
    elif command.startswith("split "):
        filename = command[command.find(' ') + 1:]
        if os.path.isfile(filename):
            explit.split(filename, filename + "_split")
            return 'output: ' + filename + "_split"
        elif os.path.exists(filename):
            compressor.zipDirectory(filename)
            explit.split(filename + '.zip', filename + ".zip_split")
            return 'split output: ' + filename + ".zip_split"
    elif command.startswith("merge "):
        directory = command[command.find(' ') + 1:]
        filename = directory.replace("_split", "")
        explit.merge(directory, filename)
        if filename.endswith(".zip"):
            compressor.unzipDirectory(filename)
        return 'merge output: ' + filename.replace(".zip","")
    elif command.startswith("decrypt "):
        filename = command.find(' ') + 1
        key = filename + command[filename:].find(' ')
        IV = raw_input('keyfile path: ')
        decrypt(command[filename:key], command[key:], open(IV,'rb').read())
        wipe.recursiveWipe(IV)
        return 'decrypted'
    elif command.startswith("zip "):
        filename = command[command.find(' ') + 1:]
        return compressor.zipDirectory(filename)
    elif command.startswith("unzip "):
        filename = command[command.find(' ') + 1:]
        return compressor.unzipDirectory(filename)
    elif command == "help":
        print """
                Advanced Shell
                Version 1.0
                Authored by VJ

                Functions:
                encrypt (filename) (key)
                decrypt (filename) (key)
                rm (foldername/filename)
                wipe (foldername/filename)
                split (foldername/filename)
                merge (foldername)
                download (url) (save path)
                all other shell functions

                Note: actions you take can be destructive
                and should be taken by extreme care
              """
    else:
        return other(command)

print """
Advanced Shell
Version 1.0
Authored by VJ
"""

while True:
    cmd = raw_input("{" + getpass.getuser() + "}" + "$ ");
    if cmd == 'exit':
        break
    else:
        try:
            output = execute(cmd)
            if output != None:
                print output.strip()
                print
            else:
                print
        except:
            print "couldn't complete request"
            print
