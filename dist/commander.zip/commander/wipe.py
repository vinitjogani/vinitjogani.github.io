import os, shutil

# overwrite a file
def wipeFile(path):
    # find file length and generate random bytes
    x = len(open(path, 'rb').read())
    d = os.urandom(x)
    # overwrite the file
    open(path, 'wb').write(d)

# wipe file multiple times
def recursiveWipe(path, times=1):
    # wipe multiple times
    for i in range(times):
        wipeFile(path)
    # delete file
    os.remove(path)

# wipe directory function
def wipeDirectory(path, times=1):
    # walk through directory
    for dirpath, directories, files in os.walk(path):
        # loop through files
        for f in files:
            # zip file
            filepath = '\\'.join([dirpath, f])
            recursiveWipe(filepath, times)
    shutil.rmtree(path)

