import compressor, crypt, wipe, explit

print """
Advanced Shell
Version 1.0
"""

n=raw_input("$ ")
while ((n) != "exit"):
    print n
    n=raw_input("$ ")
