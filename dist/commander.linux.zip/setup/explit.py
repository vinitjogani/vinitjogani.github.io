import os,  math, glob

# main split function
def split(filename, directory, DUMP_SIZE=1024 * 1024 * 10):
    # create directory if it doesn't exist already
    if not os.path.exists(directory):
        os.makedirs(directory)
    if not (directory.endswith('\\') or directory.endswith('/')):
        directory += '/'
    # check if file exists    
    if os.path.isfile(filename):
        # read input file
        data = open(filename, 'rb').read()
        loops = int(math.ceil(len(data) * 1.00 / DUMP_SIZE))
        for i in range(loops):
            if (i+1) == loops:
                open(directory + str(i+1) + '.explit', 'wb').write(data[i*DUMP_SIZE:])
            else:
                open(directory + str(i+1) + '.explit', 'wb').write(data[i*DUMP_SIZE:(i+1)*DUMP_SIZE])

# main merging cuntion
def merge(directory, filename):
    # open the output file
    output = open(filename, 'wb')
    # sanity checks
    if not (directory.endswith('\\') or directory.endswith('/')):
        directory += '/'
    # loop through all explit files
    for f in range(1, len(glob.glob(directory + '*.explit')) + 1):
        output.write(open(directory + str(f) + ".explit", 'rb').read())
    # close output stream
    output.close()
