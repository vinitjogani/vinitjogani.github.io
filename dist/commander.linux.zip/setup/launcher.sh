#!/bin/sh
python /etc/commander/commander.py
