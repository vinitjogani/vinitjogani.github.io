import zipfile, os

# zipping function
def zipDirectory(path):
    # open zip file
    z = zipfile.ZipFile(path + '.zip', mode='w')
    # walk through directory
    for dirpath, directories, files in os.walk(path):
        # loop through files
        for f in files:
            # zip file
            filepath = '\\'.join([dirpath, f])
            z.write(filepath)
    # close zip file
    z.close()

# unzipping function
def unzipDirectory(path):
    # open zip file
    z = zipfile.ZipFile(path, mode='r')
    # loop through files
    for f in z.infolist():
        #read file into the destination dir
        filename = f.filename.replace('\\','/')
        directory = filename[:filename.rfind('/')+1]
        if not os.path.exists(directory):
            os.makedirs(directory) 
        open(f.filename, 'wb').write(z.read(f.filename))


